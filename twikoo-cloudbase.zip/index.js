const twikoo = require('twikoo-func')
exports.main = async (event, context) => twikoo.main(event, context)
